//当上一层无法执行时  不会执行下一层
//注意 当上一个调用的方法返回为空时  此时用做if判断不会报错  但用于调用下一个方法时会报错

//level=>世界   server=>服务器(可用于执行命令)
//event.level.getBlock(new blockPos(entity.x,(entity.y+5),entity.z)).set('water')
//






let Reaction = (event) => {//不能在server控制元素效果(effect)

  //event.server.tell('34452')
  let entity = event.entity

  let source = event.source

  if (!(entity && entity.isLiving() && source.actual && source.actual.isLiving())) { return }//排除无实体



  if (isLightning(event)) {//雷攻击    <----判定存在问题                           超载||event.source.type=="lightningBolt"      


    //  event.server.tell(event.source.type)


    Lightning(event)

    //event.server.tell('4564')
    //entity.addEffect(new potions())//自动补全来源->MobEffect
  }

  else if (isFire(event)) {//火攻击

    Fire(event)


  } else if (isIce(event)) {


    Ice(event)


  } else if (isPoison(event)) {

    Poison(event)//临时



  } else if (isEnder(event)) {//末影攻击

    Ender(event)


  }

















}

//entity.persistentData.putInt('sickTime1', 0)
// let i = getEntityIndex("minecraft:generic.max_health", event)
//  let health = event.entity.nbt["Attributes"][i]["Base"]
//

//event.server.tell(entity.persistentData.getInt('sickTime1'))
//反应判定  当受到某种元素伤害时   判定实体可以反应的元素量  当某种元素量大于n时  反应并清除这个元素  如果没有可反应的元素量 则为实体附上本次反应的元素



/*
    if(onIce(event)){//融化
      let intensity  =  event.entity.getEffect("kubejs:ice").getAmplifier()  //元素量
      let time =event.entity.getEffect("kubejs:ice").getDuration()
  entity.addEffect(new potion('kubejs:water',time,intensity))
  entity.removeEffect('kubejs:ice')
  //event.server.runCommandSilent(`setblock ${entity.x} ${entity.y} ${entity.z} minecraft:water keep`)//放置水
  //evnt.level.setBlockAndUpdate('') 放置水方块
  event.level.setBlock(new blockPos(entity.x,entity.y,entity.z),new block('water'),5)
    }
  */
/*
else if (!onLightning(event) && !onIce(event) && !onPosion(event) && !onWater(event)) {//无反应 仅附着 应设定不同类型法术附着量不同
 if (onFire(event)) {
   let intensity = entity.getEffect('kubejs:fire').getAmplifier() + isFire(event)//元素量//应区分不同法术
   entity.addEffect(new potion('kubejs:fire', 200, Math.min(intensity, 20))) //<==设置最大附着量 可通过解锁获得更高

 } else {
   entity.addEffect(new potion('kubejs:fire', 200, 0))
 }

}
*/
