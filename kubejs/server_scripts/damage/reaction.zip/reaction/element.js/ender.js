

let Ender = (event) => {

    let entity = event.entity

    let source = event.source

    let id = event.source.actual.uuid

    if (onIce2(entity)) {//endermove


        //生成末影之眼
        let intensity = event.entity.getEffect("kubejs:ice").getAmplifier()  //元素量

        let time = event.entity.getEffect("kubejs:ice").getDuration()

        //event.server.tell('3452')

        let a = true
        if (intensity > 4) {
            let entits = source
                .actual
                .level
                .getEntitiesWithin(AABB.of(
                    source.actual.x - 10,
                    source.actual.y - 10,
                    source.actual.z - 10,
                    source.actual.x + 10,
                    source.actual.y + 10,
                    source.actual.z + 10))


            for (let i = 0; a && entits[i]; i++) {


                if (entits[i].type == "kubejs:ender_eye") a = false


            }

            if (!example(event, source.actual, 'kubejs:ender_eye', 10)) {
                let summoner = event.level.createEntity('kubejs:ender_eye')

                summoner.setX(source.actual.x)
                summoner.setY(source.actual.y + 1.5)
                summoner.setZ(source.actual.z)

                event.level.addFreshEntity(summoner)

                summoner.persistentData.putInt('time', 250 + 25 * intensity)
                //event.level.runCommandSilent(`/execute as ${id} at ${id} run summon aether:hammer_projectile ~ ~3 ~`)
            } else {

                //延长存在时间
            }
            //event.server.tell('34452')
        }


    } else if(onFire2(entity)){


        let intensity = entity.getEffect("kubejs:fire").getAmplifier()  //元素量

        let time = entity.getEffect("kubejs:fire").getDuration()
    
        //event.server.tell('3452')
    
        let a = true
    
        if (intensity >= 4) {//10格内不能有该实体
       
    
          if (!example(event, source.actual, 'kubejs:ender_gravity', 10)) {//此处原为a
            let summoner = event.level.createEntity('kubejs:ender_gravity')
    
            summoner.setX(source.actual.x)
            summoner.setY(source.actual.y)
            summoner.setZ(source.actual.z)
    
            event.level.addFreshEntity(summoner)
    
            summoner.persistentData.putInt('time', 300)//250 + 25 * intensity
    
            summoner.persistentData.putInt('gravity_height', Math.min(intensity - 9, 20))//跳跃高度设置
            //event.server.tell('1')
            if (entity.isPlayer() && intensity >= 14) {//玩家召唤
    
              sendSubtitle(event, source.actual, 180, 29, 145, '末影喷涌')
    
              setBooleanData(summoner, 'goal', true)//阵营为玩家
    
              setIntData(summoner, 'att',((intensity - 14) * 0.1 + 1) * 3 * Damage2(entity, 'reaction2'))//给服务端实体添加nbt
    
            } else if (intensity >= 14) {
    
              sendSubtitle(event, source.actual, 180, 29, 145, '末影喷涌')
    
              setBooleanData(summoner, 'goal', false)
    
              setIntData(summoner, 'att', ((intensity - 14) * 0.1 + 1) *3 * entityAtt(event))
    
            } else {
    
              sendSubtitle(event, source.actual, 180, 29, 145, '末影抬升')
    
    
            }
    
    
            //event.level.runCommandSilent(`/execute as ${id} at ${id} run summon aether:hammer_projectile ~ ~3 ~`)
          } else {
    
            //延长存在时间
          }
          // event.server.tell('34452')
        }


    }
    
    
    
    else if (false) {//onWater2(entity) 此处代码移动到灾厄元素

        //event.server.tell('643534')

        //  let goal = Java.loadClass("net.minecraft.world.entity.ai.goal.Goal")


        /**@type {Internal.Mob} */
        let summoner = event.level.createEntity('minecraft:endermite')

        summoner.setX(entity.x)
        summoner.setY(entity.y + 3.5)
        summoner.setZ(entity.z)



        summoner.setTarget(entity)//设置攻击目标

        //summoner.targetSelector.addGoal(0,  goal.arguments)


        global.goalEntity[entity.stringUuid] = entity//将受击者对象存入global 索引为其id


        //  event.server.tell(global.goalEntity[entity.stringUuid])

        event.level.addFreshEntity(summoner)

        summoner.persistentData.putString('goal', entity.stringUuid)//将受击者id保存在召唤物身上

       // summoner.captureDrops().remove()


    }
    event.server.tell(2)


}











