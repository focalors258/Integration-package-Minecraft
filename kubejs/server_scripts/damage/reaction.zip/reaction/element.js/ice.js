let Ice = (event) => {


    let entity = event.entity

    let source = event.source

    //event.server.tell('cnm')
    if (onFire(event)) {//冰附着量低:升华 生成水蒸气 造成伤害 冰附着量高:融化 生成水方块 暂时放在雷伤害激活



        let intensity = event.entity.getEffect("kubejs:fire").getAmplifier()  //元素量

        let time = event.entity.getEffect("kubejs:fire").getDuration()


        if (intensity >= 14) {//融化
            if (entity.level.getBlockState(new blockPos(source.actual.x, source.actual.y, source.actual.z)).block.id == 'minecraft:air') {//该位置为空气时
                event.level.getBlock(new blockPos(source.actual.x, source.actual.y, source.actual.z)).set('water')  //<=======
            }
        }

    } else if (onEnder(event)) {


        //event.server.tell('3452')
        let id = entity.uuid


        let intensity = event.entity.getEffect("kubejs:ender").getAmplifier()  //元素量

        let time = event.entity.getEffect("kubejs:ender").getDuration()

        //event.server.tell('345452')
        if (intensity >= 4) {
            /*
            let a = true
            // event.server.tell('756')

            let entitys = entity.level
                .getEntitiesWithin(AABB.of(
                    entity.x - 10,
                    entity.y - 10,
                    entity.z - 10,
                    entity.x + 10,
                    entity.y + 10,
                    entity.z + 10))

           // event.server.tell('756')
            for (let i = 0; a && entitys[i]; i++) {

                //event.server.tell('nmsl')

                if (entitys[i].type == "kubejs:ender_eye") a = false


            }
*/
            //event.server.tell(a)   

            if (!example(event, entity, 'kubejs:ender_eye', 10)) {//此处原为a
                let summoner = event.level.createEntity('kubejs:ender_eye')

                summoner.setX(entity.x)
                summoner.setY(entity.y + 3.5)
                summoner.setZ(entity.z)

                event.level.addFreshEntity(summoner)

                summoner.persistentData.putInt(time, 250 + 25 * intensity)
                // event.level.runCommandSilent(`/execute as ${id} at ${id} run summon aether:hammer_projectile ~ ~3 ~`)
            }
        }

    }


}