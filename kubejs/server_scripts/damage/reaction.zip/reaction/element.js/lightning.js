let Lightning = (event) => {


  let entity = event.entity

  let source = event.source

  let reactionTheMagic = source.actual.getAttributes().getValue('kubejs:reaction_magic')



  if (onFire(event)) {//超载

    let intensity = event.entity.getEffect("kubejs:fire").getAmplifier()  //元素量

    let time = event.entity.getEffect("kubejs:fire").getDuration()



    if (intensity >= 9) {

      sendSubtitle(event,entity, 246, 58, 21, '引爆')

      event.level
        .createExplosion(entity.x, entity.y, entity.z)
        .strength(intensity * Damage(event, 'reaction3') / 5)//
        .damagesTerrain(false)
        .causesFire(false)
        .exploder(source.actual)
        .explode()

      entity.invulnerableTime = 0


    } else {

      sendSubtitle(event,entity, 246, 58, 21, '点火')

      if (entity.level.getBlockState(new blockPos(entity.x, entity.y, entity.z)).block.id == 'minecraft:air') {//该位置为空气时
        event.level.getBlock(new blockPos(entity.x, entity.y, entity.z)).set('fire')  //<=======
      }

    }

  } else if (onIce(event)) {

















  }



  else if (onPosion(event)) {

    let intensity = event.entity.getEffect("kubejs:posion").getAmplifier()  //元素量

    let time = event.entity.getEffect("kubejs:posion").getDuration()



    entity.level.getEntitiesWithin(AABB.of(
      entity.x - 4,
      entity.y - 1,
      entity.z - 4,
      entity.x + 4,
      entity.y + 3.5,
      entity.z + 4)).forEach(entitys => {









      })























  }






























}