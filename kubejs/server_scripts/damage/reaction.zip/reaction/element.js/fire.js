let Fire = (event) => {


  let entity = event.entity

  let source = event.source

  let reactionTheMagic = source.actual.getAttributes().getValue('kubejs:reaction_magic')


  if (onLightning(event)) {//超载

    let intensity = event.entity.getEffect("kubejs:lightning").getAmplifier()  //元素量

    let time = event.entity.getEffect("kubejs:lightning").getDuration()

    if (intensity >= 9) {

      event.level
        .createExplosion(source.actual.x, source.actual.y, source.actual.z)
        .strength(intensity * Damage(event, 'reaction3') / 5)//
        .damagesTerrain(false)
        .causesFire(false)
        .exploder(entity)
        .explode()

      source.actual.invulnerableTime = 0//重置无敌时间

      sendSubtitle(event, source.actual, 246, 58, 21, '引爆')


    } else {

      sendSubtitle(event, source.actual, 246, 58, 21, '点火')

      if (entity.level.getBlockState(new blockPos(source.actual.x, source.actual.y, source.actual.z)).block.id == 'minecraft:air') {//该位置为空气时
        event.level.getBlock(new blockPos(source.actual.x, source.actual.y, source.actual.z)).set('fire')  //<=======
      }

    }

  } else if (onIce(event)) {



    let intensity = event.entity.getEffect("kubejs:ice").getAmplifier()  //元素量

    let time = event.entity.getEffect("kubejs:ice").getDuration()


    if (intensity >= 14) {
      if (entity.level.getBlockState(new blockPos(entity.x, entity.y, entity.z)).block.id == 'minecraft:air') {//该位置为空气时
        event.level.getBlock(new blockPos(entity.x, entity.y, entity.z)).set('water')  //<=======
      }
    }


  } else if (onWater(event)) {





  } else if (onEnder(event)) {


    let intensity = event.entity.getEffect("kubejs:ender").getAmplifier()  //元素量

    let time = event.entity.getEffect("kubejs:ender").getDuration()

    //event.server.tell('3452')

    let a = true

    if (intensity >= 4) {//10格内不能有该实体
      /*
            let entitys = source
              .actual
              .level
              .getEntitiesWithin(AABB.of(
                entity.x - 10,
                entity.y - 10,
                entity.z - 10,
                entity.x + 10,
                entity.y + 10,
                entity.z + 10))
      
      
            for (let i = 0; a && entitys[i]; i++) {
      
              if (entitys[i].type == "kubejs:ender_gravity") a = false
            }
      */


      if (!example(event, entity, 'kubejs:ender_gravity', 10)) {//此处原为a
        let summoner = event.level.createEntity('kubejs:ender_gravity')

        summoner.setX(entity.x)
        summoner.setY(entity.y)
        summoner.setZ(entity.z)

        event.level.addFreshEntity(summoner)

        summoner.persistentData.putInt('time', 300)//250 + 25 * intensity

        summoner.persistentData.putInt('gravity_height', Math.min(intensity - 9, 20))//跳跃高度设置
        //event.server.tell('1')
        if (source.actual.isPlayer() && intensity >= 14) {//玩家召唤

          sendSubtitle(event, entity, 180, 29, 145, '末影喷涌')

          setBooleanData(summoner, 'goal', true)//阵营为玩家

          setIntData(summoner, 'att', ((intensity - 14) * 0.1 + 1) * 3 * Damage2(source.actual, 'reaction2'))//给服务端实体添加nbt

event.server.tell(((intensity - 14) * 0.1 + 1) * 3 * Damage2(source.actual, 'reaction2'))

        } else if (intensity >= 14) {

          sendSubtitle(event, entity, 180, 29, 145, '末影喷涌')

          setBooleanData(summoner, 'goal', false)

          setIntData(summoner, 'att',((intensity - 14) * 0.1 + 1) * 3 * actualAtt(event))

        } else {

          sendSubtitle(event, entity, 180, 29, 145, '末影抬升')


        }


        //event.level.runCommandSilent(`/execute as ${id} at ${id} run summon aether:hammer_projectile ~ ~3 ~`)
      } else {

        //延长存在时间
      }
      // event.server.tell('34452')
    }


  }












}