//把扩散反应的level类实际效果补上


let Poison = (event) => {//使用毒伤害攻击


    let entity = event.entity

    let source = event.source


    let intensity //元素量

    // let time = event.entity.getEffect("minecraft:poison").getDuration()

    let effectName





    entity.level.getEntitiesWithin(AABB.of(
        entity.x - 4,
        entity.y - 1,
        entity.z - 4,
        entity.x + 4,
        entity.y + 3.5,
        entity.z + 4)).forEach(entitys => {


           

        })
}